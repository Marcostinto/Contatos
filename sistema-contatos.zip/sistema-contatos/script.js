
console.log("Sistema de contatos carregado!");
